// Copy this file to "config.js" (which is .gitignored) and fill in your real keys.
// index.html will auto-load window.ATLAS7_CONFIG on startup if config.js is present.
// Never rename this file to config.js and commit it — keep your real keys local only.

window.ATLAS7_CONFIG = {
  provider: "anthropic",        // "anthropic" | "openai" | "groq" | "custom"
  apiKey: "sk-REPLACE-ME",
  model: "claude-sonnet-4-6",
  baseUrl: "",                  // only needed for provider: "custom"

  marketProvider: "fmp",        // "fmp" | "alphavantage"
  marketKey: "REPLACE-ME"
};
